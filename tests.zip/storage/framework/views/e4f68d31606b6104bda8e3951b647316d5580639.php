<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
    <title>Product Billing</title>
</head>
<style>
    .container{
    background: white;
    box-shadow: 0px 0px 15px rgb(0 0 0 / 8%);
    padding: 50px;
    margin-top: 50px;
    }
    </style>
<body>


<div class="container">
 <form method="post">   
  <div class="row clearfix">
    <div class="col-md-12">
    <p class="text-muted">Bill To</p>
              
              <div class="col-md-6 col-sm-12 text-md-left">
                <ul class="px-0 list-unstyled">
                 <li>Bill# </li>   
                  <li>Customer Name: <input type="text" name="username" required></li>
                  <li>Customer Address: <input type="text" name="address" required></li>
                </ul>
              </div>
              <div class="col-md-6 col-sm-12 text-center text-md-right">
                <p>
                  <span class="text-muted">Invoice Date :</span> <?php echo e(date('d-m-Y')); ?></p>
               
              </div>
            
      <table class="table table-bordered table-hover" id="tab_logic">
        <thead>
          <tr>
            <th class="text-center"> # </th>
            <th class="text-center"> Product </th>
            <th class="text-center"> Qty </th>
            <th class="text-center"> Price </th>
            <th class="text-center"> Tax</th>
            <th class="text-center"> Tax Amount </th>
            <th class="text-center"> Total </th>
          </tr>
        </thead>
        <tbody>
          <tr id='addr0'>
            <td>1</td>
            <td><input type="text" name='product[]'  placeholder='Enter Product Name' class="form-control"/></td>
            <td><input type="number" name='qty[]' placeholder='Enter Qty' class="form-control qty" step="0" min="0"/></td>
            <td><input type="number" name='price[]' placeholder='Enter Unit Price' class="form-control price" step="0.00" min="0"/></td>
            <td><select name='tax[]'  class="form-control tax">
                <option value="0">0%</option>
                <option value="1">1%</option>
                <option value="5">5%</option>
                <option value="10">10%</option>
            </select></td>
            <td><input type="number" name='tax_amount[]' placeholder='Tax Amount' class="form-control tax_amount" readonly/></td>
            <td><input type="number" name='total[]' placeholder='0.00' class="form-control total" readonly/></td>
          </tr>
          <tr id='addr1'></tr>
        </tbody>
      </table>
    </div>
  </div>
  <div class="row clearfix">
    <div class="col-md-12">
      <button id="add_row" class="btn btn-default pull-left">Add Row</button>
      <button id='delete_row' class="pull-right btn btn-default">Delete Row</button>
    </div>
  </div>
  <div class="row clearfix" style="margin-top:20px">
    <div class="pull-right col-md-4">
      <table class="table table-bordered table-hover" id="tab_logic_total">
        <tbody>
          <tr>
            <th class="text-center">Sub Total (with tax)</th>
            <td class="text-center"><input type="number" name='sub_total' placeholder='0.00' class="form-control" id="sub_total" readonly/></td>
          </tr>
          <tr>
            <th class="text-center">Sub Total (without tax)</th>
            <td class="text-center"><input type="number" name='sub_total_without_tax' placeholder='0.00' class="form-control" id="total_without_tax" readonly/></td>
          </tr>
          <tr>
            <th class="text-center">Discount</th>
            <td class="text-center"><input type="number" name='discount' id="discount"  class="form-control"/></td>
          </tr>
          <tr>
            <th class="text-center">Grand Total</th>
            <td class="text-center"><input type="number" name='total_amount' id="total_amount" placeholder='0.00' class="form-control" readonly/></td>
          </tr>
        </tbody>
      </table>


    </div>
  </div>
  <div class="text-center">
      <button type="submit" class="btn btn-primary">Genereate Invoice</button>
    </div>
</form>
</div>
</body>
</html>

<Script>
    $(document).ready(function(){
    var i=1;
    $("#add_row").click(function(){b=i-1;
      	$('#addr'+i).html($('#addr'+b).html()).find('td:first-child').html(i+1);
      	$('#tab_logic').append('<tr id="addr'+(i+1)+'"></tr>');
      	i++; 
  	});
    $("#delete_row").click(function(){
    	if(i>1){
		$("#addr"+(i-1)).html('');
		i--;
		}
		calc();
	});
	
	$('#tab_logic tbody').on('keyup change',function(){
		calc();
	});
	$('#discount').on('keyup change',function(){
		calc_total();
	});
	

});

function calc()
{
	$('#tab_logic tbody tr').each(function(i, element) {
		var html = $(this).html();
		if(html!='')
		{
			var qty = $(this).find('.qty').val();
			var price = $(this).find('.price').val();
            var tax = $(this).find('.tax').val();
            var product_total = qty*price;
            var tax_amount = (tax*product_total)/100;
            var total_with_tax = product_total+tax_amount;
			$(this).find('.total').val(total_with_tax);
            $(this).find('.tax_amount').val(tax_amount);

			calc_total();
		}
    });
}

function calc_total()
{
	total=0;
    tax_sum=0;
	$('.total').each(function() {
        total += parseInt($(this).val());
    });
    $('.tax_amount').each(function() {
        tax_sum += parseInt($(this).val());
    });
    var discount = $('#discount').val();
    $('#total_without_tax').val((total-tax_sum).toFixed(2)); 
	$('#sub_total').val(total.toFixed(2));
	$('#total_amount').val((total-discount).toFixed(2));
}
</Script><?php /**PATH C:\laragon\www\blog\resources\views/welcome.blade.php ENDPATH**/ ?>